# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Development Commands

### Core Commands
- `npm run dev` - Start development server on localhost:3000
- `npm run build` - Build production bundle 
- `npm run start` - Start production server
- `npm run lint` - Run ESLint for code quality
- `npm test` - Run Jest test suite

### Development Server Management
If experiencing caching issues or status inconsistencies, restart with:
```bash
# Stop server (Ctrl+C)
rmdir /S /Q .next  # Windows
# or rm -rf .next   # Unix/Mac
npm cache clean --force
npm run dev
```

### Alternative Development Server Management (PowerShell)
Use the provided scripts for automated server restart:
```powershell
# Windows PowerShell
./restart-dev.ps1

# Windows Command Prompt
restart-dev.bat
```

## Architecture Overview

### System Purpose
PCRD Smart Request Management System - A comprehensive laboratory testing workflow management platform specifically designed for polymer and material testing. The system streamlines the entire testing lifecycle from request submission to result delivery, handling three types of requests: NTR (New Test Request), ASR (Additional Sample Request), and ER (Emergency Request).

### Technology Stack
- **Frontend**: Next.js 15.1.0 with TypeScript, React 19
- **UI Components**: Radix UI primitives with Tailwind CSS and shadcn/ui
- **Backend**: Next.js App Router API routes
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: Custom role-based system (user, admin, lab_manager)

### Key Data Models

#### Core Entities
- **RequestList**: Master request records with status tracking, sample information, and evaluation data
- **TestingSampleList**: Individual testing samples with equipment assignments, method details, and progress tracking
- **Equipment**: Laboratory equipment with capabilities and availability
- **TestingMethod**: Available test methods with pricing and turnaround times
- **Capability**: Laboratory capabilities that group testing methods
- **User**: System users with role-based permissions

#### Request Workflow
1. **Request Creation**: Users create requests with samples and select test methods
2. **Method Instances**: Test methods can have multiple "repeats" with different requirements
3. **Capability Grouping**: Methods are automatically grouped by capability and split into separate requests
4. **Status Progression**: Pending Receive → In Progress → Completed
5. **Sample Tracking**: Individual samples tracked through testing lifecycle

### Critical Status Management

#### Request Statuses
- `Pending Receive` - Submitted, awaiting sample receipt
- `in-progress` - Samples received, testing in progress  
- `completed` - All testing completed
- `rejected`, `terminated`, `cancelled` - Various end states

#### Sample Statuses
- `Pending Receive` - Awaiting physical sample
- `in-progress` - Sample received and being tested
- `completed` - Testing finished

**Important**: After server restarts, verify status consistency in submit APIs. See STATUS_UPDATE_INSTRUCTIONS.md for specific line references.

### Database Connection
- MongoDB connection cached in `lib/db.js`
- Environment: `MONGODB_URI` (defaults to `mongodb://localhost:27017/smr_augment`)
- Models defined in `models/` directory with both .js and .ts versions

### API Architecture

#### Key API Patterns
- **CRUD Operations**: Standard REST patterns for all entities
- **Request Submission**: Complex multi-step process handling capability grouping and sample distribution
- **Status Management**: Atomic updates with status synchronization between RequestList and TestingSampleList
- **File Uploads**: Equipment images and method documentation

#### Critical API Routes
- `/api/requests/submit-request` - NTR submission with capability splitting
- `/api/requests/manage` - Request status updates with cascading changes
- `/api/testing-samples` - Individual sample management and status tracking
- `/api/equipment` - Equipment CRUD with image upload support

### Frontend Architecture

#### Page Structure
- **Dashboard**: Main interface with request overview and quick actions
- **Request Creation**: Multi-step wizard (NTR/ASR/ER) with sample definition and method selection
- **Request Management**: Status tracking with Request and Testing views
- **Admin**: Database configuration for all system entities

#### State Management
- **LocalStorage**: Temporary form data persistence during multi-step workflows
- **React State**: Component-level state with manual synchronization
- **No Global State**: Direct API calls with manual cache invalidation

#### Component Patterns
- **Dialogs**: Radix Dialog components for CRUD operations
- **Forms**: React Hook Form with Zod validation
- **Data Tables**: Custom table implementations with sorting and filtering
- **Status Badges**: Consistent status display across the application

### Authentication & Authorization

#### Role System
- **user**: Create requests, view own requests
- **lab_manager**: Manage testing workflow, update sample status
- **admin**: Full system access, database configuration

#### Implementation
- Custom auth provider in `components/auth-provider.tsx`
- Role checks in API routes and protected components
- localStorage-based session management (development setup)

### File Structure Conventions

#### API Routes (`app/api/`)
- RESTful structure with `[id]` dynamic routes
- Both `.js` and `.ts` files (migration in progress)
- Route handlers follow Next.js App Router patterns

#### Components (`components/`)
- **UI Components**: `ui/` directory with Radix-based primitives
- **Feature Components**: Domain-specific dialogs and forms
- **Layout Components**: Dashboard layout and navigation

#### Models (`models/`)
- Mongoose schemas with comprehensive validation
- Both `.js` and `.ts` versions during TypeScript migration
- Detailed field documentation and relationships

### Development Considerations

#### Database Operations
- Always use `connectToDatabase()` in API routes
- Clear Mongoose model cache when schema changes occur
- Handle validation errors and duplicate key constraints

#### Status Synchronization
- Request status changes trigger corresponding TestingSampleList updates
- Use atomic operations for status transitions
- Verify status mappings between frontend and database enums

#### Test Method Instances
- Methods can have multiple "repeats" with individual requirements
- Display all repeats in summary (Repeat #1, #2, etc.)
- Create separate TestingSampleList records for each repeat
- Use `_R1`, `_R2` suffixes in sample naming for tracking

## Print System Architecture

### Request Confirmation Page (`/app/request/new/ntr/confirmation/page.tsx`)
The confirmation page handles printing and PDF generation for submitted requests with sophisticated multi-capability support.

#### Print Functionality Types
1. **Individual Capability Actions**: Print/download for specific capability only
2. **Global Actions**: Print/download for ALL capabilities at once

#### Print Components

##### Request Tags (A4 Professional Layout)
- **Purpose**: Official request documentation for laboratory workflow
- **Layout**: 1 request per A4 page with proper page breaks for >10 test methods
- **Content**: 
  - Header with capability-specific laboratory name (e.g., "Rheology Laboratory")
  - QR code section for request identification
  - Request information (ID, capability, submission date, completion estimate)
  - Requester information (from authenticated user context via `useAuth()`)
  - Test methods and samples with repeat grouping
  - Laboratory information and submission instructions
- **Multi-page**: Automatically splits into multiple pages when >10 test methods
- **Branding**: Dynamic laboratory name based on capability

##### Sample Tags (Square Card Layout)
- **Purpose**: Physical tags to attach to sample containers (zip bags, bottles)
- **Layout**: 6 square cards per A4 page (3×2 grid)
- **Dimensions**: ~60mm × 60mm per card
- **Content**:
  - Header: Capability laboratory name + Request ID
  - QR code: Top-right corner (18mm × 18mm) with sample ID
  - Sample name with repeat indicators
  - Test methods list (up to 4 shown, "+X more" if needed)
  - Generation date
- **Cut lines**: Dashed guidelines extending 5mm beyond cards for precise cutting
- **Multi-page**: Automatic pagination for >6 samples

#### Print Functions

##### Individual Capability Functions
```typescript
handlePrintTags(request): // Prints sample tags for specific capability
handlePrintRequestTag(request): // Prints request tag for specific capability  
handleDownloadPDF(request): // Downloads PDF for specific capability
```

##### Global Functions (All Capabilities)
```typescript
handlePrintAllSampleTags(): // Combines all samples from all capabilities
handlePrintAllRequestTags(): // Combines all request tags with page breaks
handleDownloadAllPDF(): // PDF version of all request tags
```

##### HTML Generation Functions
```typescript
generateRequestTagHTML(request, forPDF): // Single capability request tag
generateSinglePageHTML(request, methods, isFirstPage, pageNum, totalPages, user): // Individual page generation
generateSampleTagsHTML(request): // Single capability sample tags
generateAllSampleTagsHTML(allRequests): // Multi-capability sample tags
generateAllRequestTagsHTML(allRequests): // Multi-capability request tags
```

#### UI Layout Structure

##### Global Actions Section
Located beside capability filter tabs with distinctive styling:
- Colored gradient box (`bg-gradient-to-r from-blue-50 to-purple-50`)
- "Print All Capabilities" header text
- Three compact buttons: Request, Sample, PDF
- Horizontal layout with proper responsive behavior

##### Individual Capability Actions
Located on each capability card with consistent styling:
- Three compact buttons per capability: Request, Sample, PDF
- Matches global button styling for consistency
- Only affects the specific capability

#### Print Styling Specifications

##### A4 Print CSS
```css
@page { size: A4; margin: 15mm; }
@media print {
  body { -webkit-print-color-adjust: exact; color-adjust: exact; }
  .request-tag { max-height: 95vh; overflow: hidden; }
}
```

##### Sample Tag Grid CSS
```css
.tags-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(2, 1fr);
  gap: 5mm;
}
.tag-card { aspect-ratio: 1; } /* Square cards */
```

#### Data Flow and Processing

##### Sample Processing Logic
1. Extract samples from all methods in request(s)
2. Parse repeat indicators (`_R1`, `_R2`) from sample names
3. Remove method codes and repeat suffixes for display names
4. Group methods by sample for consolidated tags
5. Paginate into A4-optimized layouts

##### Request Processing Logic
1. Split test methods into pages (max 10 per page)
2. Generate multi-page HTML with proper page breaks
3. Include full details on first page, methods-only on subsequent pages
4. Maintain capability-specific branding throughout

#### User Authentication Integration
- Uses `useAuth()` hook to get current logged-in user
- Requester information populated from authenticated user data:
  - Name: `user.name`
  - Department: `user.department`  
  - Email: `user.email`
  - User ID: `user.id`

#### Multi-Capability Support
- Automatically handles requests split across multiple capabilities
- Maintains individual capability identity in combined prints
- Proper page breaks between capabilities in global actions
- Consistent styling and branding per capability

### Print System Best Practices

#### When Working on Print Features:
1. **Always test print preview**: Use browser's print preview to verify layout
2. **Verify page breaks**: Ensure content doesn't cut off mid-section
3. **Check responsive behavior**: Test both global and individual actions
4. **Validate data processing**: Ensure sample names and repeats display correctly
5. **Test multi-capability scenarios**: Verify proper combination and separation
6. **Maintain consistency**: Keep button styling and layout patterns consistent

#### Common Print Issues to Avoid:
- Content overflowing A4 boundaries
- Broken page breaks cutting through important content
- Inconsistent styling between individual and global actions
- Missing user authentication data in requester sections
- Improper sample name parsing for repeats and method codes

## Notification System Architecture

### Overview
The notification system provides real-time alerts for request and sample status changes, assignments, and deadlines. It replaces static notifications with a database-driven, dynamic system.

### Database Model (`models/Notification.js`)
```javascript
{
  notificationId: String,        // Auto-generated unique ID
  userId: String,               // Target user ID
  userEmail: String,            // Target user email
  title: String,               // Notification title
  message: String,             // Notification message
  type: String,               // status_change, assignment, deadline, etc.
  priority: String,           // low, medium, high, urgent
  relatedEntity: String,      // request, sample, user, system
  relatedEntityId: String,    // ID of related entity
  requestNumber: String,      // Related request number
  sampleId: String,          // Related sample ID
  isRead: Boolean,           // Read status
  isArchived: Boolean,       // Archive status
  actionUrl: String,         // Link to relevant page
  actionText: String,        // Link text
  previousStatus: String,    // For status change notifications
  newStatus: String,         // For status change notifications
  changedBy: String,         // Who made the change
  changedByEmail: String,    // Email of person who made change
  createdAt: Date,          // Creation timestamp
  readAt: Date,             // When marked as read
  archivedAt: Date,         // When archived
  expiresAt: Date,          // Optional expiration
  metadata: Mixed           // Additional data
}
```

### API Endpoints

#### Core Notification APIs
- `GET /api/notifications` - Fetch user notifications with pagination
- `POST /api/notifications` - Create custom notification
- `PATCH /api/notifications` - Bulk operations (mark as read, archive)
- `GET /api/notifications/[id]` - Get specific notification
- `PATCH /api/notifications/[id]` - Update specific notification
- `DELETE /api/notifications/[id]` - Delete specific notification
- `POST /api/notifications/create` - Create typed notifications
- `POST /api/notifications/test` - Create test notifications for development

### Dashboard Integration

#### UI Location
Notifications are displayed in a **right sidebar** on the dashboard (`/app/dashboard/page.tsx`):
- Fixed width of 384px (`lg:w-96`)
- Sticky positioning for visibility while scrolling
- Compact card design with status indicators
- Real-time updates every 30 seconds

#### Visual Design
- **Unread notifications**: Blue background (`bg-blue-50`)
- **Read notifications**: Gray background (`bg-gray-50`)
- **Priority indicators**: Border colors (urgent=red, high=orange, medium=blue, low=gray)
- **Type icons**: Different icons for status changes, assignments, deadlines
- **Unread badge**: Red circle with count in header

#### User Actions
- Mark individual notifications as read
- Mark all notifications as read
- Archive notifications (soft delete)
- Click action links to navigate to relevant pages

### Notification Triggers

#### Automatic Triggers
1. **Request Status Changes** (`/api/requests/manage/route.ts`)
   - Triggered when request status is updated
   - Notifies request owner
   - Includes previous and new status

2. **Sample Status Changes** (`/api/testing-samples/receive/route.ts`)
   - Triggered when samples are received
   - Notifies request owner
   - Includes sample count and request number

#### Notification Types
- `status_change` - Request/sample status updates
- `assignment` - New task assignments
- `deadline` - Approaching or overdue deadlines
- `completion` - Task completions
- `approval_required` - Actions needing approval
- `system_update` - System maintenance notices
- `urgent` - High-priority alerts
- `info` - General information

### Implementation Details

#### Frontend State Management
```typescript
// State variables in dashboard
const [notifications, setNotifications] = useState<any[]>([])
const [notificationLoading, setNotificationLoading] = useState(true)
const [unreadCount, setUnreadCount] = useState(0)

// Key functions
fetchNotifications() - Load notifications from API
markNotificationAsRead(id) - Mark single notification as read
markAllNotificationsAsRead() - Mark all as read
archiveNotification(id) - Archive single notification
```

#### Real-time Updates
- Initial load on component mount
- Refresh every 30 seconds via `setInterval`
- Updates when user changes (email-based filtering)

### Best Practices

#### When Creating Notifications:
1. Always include meaningful titles and messages
2. Set appropriate priority levels
3. Include action URLs for quick navigation
4. Use correct notification types for proper categorization
5. Include relevant entity IDs for tracking

#### When Modifying the System:
1. Test notification creation in status change APIs
2. Verify real-time updates in dashboard
3. Check responsive design on different screen sizes
4. Ensure proper error handling for failed notifications
5. Monitor performance with large notification counts

## Dashboard Expense Tracking System

### Overview
The dashboard displays IO (Internal Order) budget tracking with real-time cost calculations from testing samples.

### Expense Data Flow
1. **IO Numbers Collection**: Extracted from user's requests
2. **IO Budget Fetching**: Retrieved from `/api/ios` endpoint
3. **Testing Cost Calculation**: Summed from `TestingSampleList.testingCost`
4. **Filtering**: By selected IOs and date range

### Key Components

#### Expense Card (`/app/dashboard/page.tsx`)
- **Location**: Top-right of summary section
- **Color Scheme**: Purple gradient (`from-purple-50 to-indigo-50`)
- **Display Values**:
  - IO Budget: Total allocated budget
  - IO Spending: Current spending from IO data
  - IO Budget Used: Sum of testing costs from samples
  - Progress Bar: Visual representation of budget usage

#### Data Calculation (`fetchExpenseData` function)
```javascript
// Key steps:
1. Get unique IO numbers from requests
2. Fetch IO data for budget/spending
3. Query TestingSampleList for all samples
4. Filter samples by:
   - User's requests only
   - Selected IO numbers
   - Date range (if specified)
5. Sum testingCost field from filtered samples
```

### Debug Features
The system includes comprehensive logging for troubleshooting:
- Request counts and IO numbers
- Filtered sample counts
- Individual sample costs
- Total calculations

### Common Issues and Solutions

#### IO Budget Shows 0
**Causes**:
1. No testing samples in database
2. `testingCost` field is null/0 in samples
3. Filters excluding all samples
4. Test methods missing price data

**Solutions**:
1. Verify TestingSampleList has entries
2. Check if methods have `price` field populated
3. Review filter settings (IO/date range)
4. Ensure `method.price` is passed during request submission

## Print Tag System in Dashboard

### Overview
The dashboard includes a print tag system accessible via the 3-dot menu on each request card.

### Print Options
1. **Print All Request** - Prints formal request documentation
2. **Print Sample Tag** - Prints labels for sample containers

### Implementation Details

#### Menu Structure (`/app/dashboard/page.tsx`)
```tsx
<DropdownMenuSub>
  <DropdownMenuSubTrigger>
    <Printer className="mr-2 h-4 w-4" />
    Print Tag
  </DropdownMenuSubTrigger>
  <DropdownMenuSubContent>
    <DropdownMenuItem onClick={() => handlePrintAllRequest(request.id)}>
      Print All Request
    </DropdownMenuItem>
    <DropdownMenuItem onClick={() => handlePrintSampleTag(request.id)}>
      Print Sample Tag
    </DropdownMenuItem>
  </DropdownMenuSubContent>
</DropdownMenuSub>
```

#### Data Processing
1. Fetches request details from `/api/requests/details`
2. Parses `jsonTestingList` for test methods
3. Transforms complex method structure to simple format:
   ```javascript
   // From: { id, name, selected, instances, samples, price }
   // To: { name, samples }
   ```
4. Handles method instances/repeats properly
5. Generates HTML for printing

### API Data Transformation
The `/api/requests/details` endpoint transforms stored test method data:
- Filters only selected methods
- Expands instances into separate entries
- Adds repeat indicators to method names
- Flattens nested structure for print templates

## Recent Bug Fixes and Improvements

### 1. IO Number Submission Fix
**Issue**: IO number was using mockup data instead of user input
**Solution**: Updated `/api/requests/submit-request/route.js` to use `body.ioNumber` directly

### 2. Dashboard Expense Calculation
**Issue**: Not calculating from TestingSampleList
**Solution**: Implemented proper aggregation of `testingCost` from samples

### 3. Print Tag Empty Data
**Issue**: Print forms showed no data
**Solution**: Added data transformation in API to match print template expectations

### 4. Notification System Variable Scope
**Issue**: `filteredSamples` not defined error
**Solution**: Declared variable outside try-catch block

### 5. Build Errors
**Issue**: Duplicate variable declarations and incorrect imports
**Solution**: Removed duplicate code and fixed import statements

## Development Tips

### When Adding New Features:
1. Check both .js and .ts versions of models
2. Use `dbConnect()` not `connectToDatabase()` in API routes
3. Handle status synchronization between RequestList and TestingSampleList
4. Test with different user roles (user, lab_manager, admin)
5. Verify localStorage data persistence in multi-step forms

### When Debugging:
1. Check browser console for API responses
2. Verify MongoDB connection status
3. Look for status mapping issues between frontend/backend
4. Check if required fields are properly populated
5. Use debug logging strategically (remove in production)

### Performance Considerations:
1. Implement pagination for large datasets
2. Use proper MongoDB indexes (already defined in models)
3. Cache expensive calculations when possible
4. Minimize API calls with batch operations
5. Use React hooks properly to prevent re-renders